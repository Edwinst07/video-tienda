package org.lpav2.videotienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideotiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
