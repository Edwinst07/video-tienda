package org.lpav2.videotienda;

import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class UploadConfig implements WebMvcConfigurer {
	
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		WebMvcConfigurer.super.addResourceHandlers(registry);
		
		String rutaAbsUploads = Paths.get("uploads").toAbsolutePath().toUri().toString();
		
		log.info("rutaAbsUploads: " + rutaAbsUploads + " en " + getClass());
		
		// con el parámetro registry registrar la nueva ruta url para este caso /uploads/
		// e indicar el directorio físico con el que se va a relacionar
		registry.addResourceHandler("/uploads/**").addResourceLocations(rutaAbsUploads);
	}
}
