package org.lpav2.videotienda.model.dao;

import java.util.List;

import org.lpav2.videotienda.model.entity.Pelicula;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PeliculaDAO extends PagingAndSortingRepository<Pelicula, Long> {

    @Query("select p from Pelicula p where p.titulo like %?1%")
    public List<Pelicula> buscarPorTitulo(String term);
}
